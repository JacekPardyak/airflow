# INX
Wrapper for Inkscape https://inkscape.org/

# References 
https://packaging.python.org/en/latest/tutorials/packaging-projects/